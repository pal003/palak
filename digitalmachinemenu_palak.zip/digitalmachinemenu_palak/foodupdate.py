print()
print("......Novel Nosh......".center(100))
print("WELCOME TO OUR RESTRO".center(90))

def load_menu(filename="foodupdatetext.txt"):
    menu = {"Drinks": [], "Food": [], "Desserts": []}
    try:
        with open(filename, 'r') as file:
            category = None
            for line in file:
                line = line.strip()
                if line.endswith(':'):
                    category = line[:-1]  # Remove the colon
                elif line:
                    name, price = line.split(',')
                    menu[category].append({"name": name.strip(), "price": float(price.strip())})
                    
                    # Only add the "half" version
                    half_name = f"Half {name.strip()}"
                    half_price = float(price.strip()) / 2
                    menu[category].append({"name": half_name, "price": half_price})
                    
    except FileNotFoundError:
        print(f"Error: {filename} not found!")
    return menu

def display_menu(menu):
    print("\n--- Menu ---")
    for category, items in menu.items():
        print(f"\n{category}:")
        for item in items:
            print(f"{item['name']} - ₹{item['price']:.2f}")  # Change to INR

def take_order(menu):
    order = []
    while True:
        category = input("\nSelect a category (Drinks/Food/Desserts or 'done' to finish): ").capitalize()
        if category == 'Done':
            break
        if category in menu:
            display_items(menu[category])
            item_name = input(f"Select an item from {category}: ")
            item = next((i for i in menu[category] if i["name"].lower() == item_name.lower()), None)
            if item:
                # Ask for the quantity
                quantity = int(input(f"How many {item_name}s would you like? "))
                for _ in range(quantity):  # Add the item to the order for the specified quantity
                    order.append(item)
                print(f"Added {quantity} {item_name}(s) to your order.")
            else:
                print("Item not found in the selected category.")
        else:
            print("Invalid category. Please try again.")
    return order

def display_items(items):
    print("\nAvailable items:")
    for item in items:
        print(f"{item['name']} - ₹{item['price']:.2f}")  # Change to INR

def cancel_order(order):
    order.clear()
    print("\nOrder has been canceled.")

def calculate_total(order):
    total = sum(item['price'] for item in order)
    return total

def confirm_order(order, total):
    print("\nYour Order Summary:")
    for item in order:
        print(f"{item['name']} - ₹{item['price']:.2f}")
    print(f"\nTotal: ₹{total:.2f}")
    
    table_number = input("\nPlease enter your table number: ")
    confirm = input(f"Confirm order for Table {table_number} (yes/no): ").strip().lower()
    
    if confirm == 'yes':
        print(f"\nOrder confirmed for Table {table_number}.")
        print()
        print("Thank you for your order! and please wait you receive your order on your table.")
    else:
        print("Order not confirmed. You can modify or cancel the order.")

def main():
    menu = load_menu()
    if not menu:
        return

    order = []
    while True:
        print("\n1. View Menu")
        print("2. Select Order")
        print("3. Cancel Order")
        print("4. Total")
        print("5. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            display_menu(menu)
        elif choice == "2":
            order = take_order(menu)
        elif choice == "3":
            cancel_order(order)
        elif choice == "4":
            total = calculate_total(order)
            print(f"Total order cost: ₹{total:.2f}")  # Change to INR
            confirm_order(order, total)  # Ask for table number and confirmation
        elif choice == "5":
            print("Thank you for coming!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
